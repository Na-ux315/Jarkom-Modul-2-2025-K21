# Lindon
apt-get update && apt-get install nginx -y

mkdir -p /var/www/lindon/annals

cat > /var/www/lindon/annals/index.html

systemctl enable --now nginx

# Di Client
curl -I http://static.K21.com/annals/