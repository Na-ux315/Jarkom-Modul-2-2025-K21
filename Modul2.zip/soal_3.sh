echo "nameserver 192.168.122.1" > /etc/resolv.conf

ping 10.74.2.2

ping 10.74.1.2