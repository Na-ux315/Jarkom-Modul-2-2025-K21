nano /etc/bind/zones/db.K21.com

// Lalu tambahkan bagian nomor serialnya +1 (awalnya 1 → 2)
// Tambahkan juga

www.K21.com.        IN      CNAME   Sirion.K21.com.
static.K21.com.     IN      CNAME   Lindon.K21.com.
app.K21.com.        IN      CNAME   Vingilot.K21.com.

apt-get update && apt-get install bind9 -y

named-checkconf

named-checkzone K21.com /etc/bind/db.K21.com

named

nano /etc/resolv.conf

nameserver 10.74.3.2    # Tirion (ns1) -> ini yang ditambah
nameserver 10.74.3.3    # Valmar (ns2) -> ini yang ditambah
nameserver 192.168.122.1

dig www.K21.com
dig static.K21.com
dig app.K21.com