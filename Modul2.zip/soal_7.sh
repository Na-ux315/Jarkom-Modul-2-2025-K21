nano /etc/bind/zones/db.K21.com

// Lalu tambahkan bagian nomor serialnya +1 (awalnya 1 → 2)
// Tambahkan juga

www.K21.com.        IN      CNAME   Sirion.K21.com.
static.K21.com.     IN      CNAME   Lindon.K21.com.
app.K21.com.        IN      CNAME   Vingilot.K21.com.