dig @10.74.3.3 K21.com SOA

dig @10.74.3.2 K21.com SOA