# Vingilot
apt-get update && apt-get install nginx -y php8.4-fpm php8.4-cli

systemctl enable --now nginx php8.4-fpm

curl -I http://app.K21.com/ 

curl -I http://app.K21.com/about