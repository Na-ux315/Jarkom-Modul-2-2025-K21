echo "eonwe" > /etc/hostname
hostname -F /etc/hostnam

nano /etc/bind/zones/db.K21.com

// Tambahkan ini

Eonwe.K21.com.      IN      A       10.74.1.1
Earendil.K21.com.   IN      A       10.74.1.2
Elwing.K21.com.     IN      A       10.74.1.3
Cirdan.K21.com.     IN      A       10.74.2.2
Elrond.K21.com.     IN      A       10.74.2.3
Maglor.K21.com.     IN      A       10.74.2.4
Sirion.K21.com.     IN      A       10.74.3.6
Lindon.K21.com.     IN      A       10.74.3.5
Vingilot.K21.com.   IN      A       10.74.3.4

named-checkzone K21.com /etc/bind/zones/db.K21.com

Service named restart

dig earendil.K21.com

dig sirion.K21.com