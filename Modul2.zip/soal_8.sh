# Tirion
apt-get update && apt-get install bind9 -y

service named restart

named-checkconf

named-checkzone 3.74.10.in-addr.arpa /etc/bind/db.10.74.3

dig -x 10.74.3.6 @10.74.3.2

# Valmar
apt-get update && apt-get install bind9 -y

service named restart

named-checkconf

dig -x 10.74.3.6 @10.74.3.3