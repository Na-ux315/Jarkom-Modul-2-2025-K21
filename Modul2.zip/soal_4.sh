apt-get update && apt-get install bind9 -y

nano /etc/bind/named.conf.options

options {
        directory "/var/cache/bind";
};
forwarders { 192.168.122.1; };

nano /etc/bind/named.conf.local

zone "K21.com" { type master; file "/etc/bind/db.K21.com"; allow-transfer { 10.74.3.3; }; // IP Valmar notify yes; };

nano /etc/bind/db.K21.com

$TTL    604800
@   IN  SOA ns1.K21.com. admin.K21.com. (
            1           ; Serial
            604800      ; Refresh
            86400       ; Retry
            2419200     ; Expire
            604800 )    ; Negative Cache TTL
;
@   IN  NS  ns1.K21.com.
@   IN  NS  ns2.K21.com.

@   IN  A   10.74.3.6    ; Sirion
ns1 IN  A   10.74.3.2    ; Tirion
ns2 IN  A   10.74.3.3    ; Valmar

named-checkconf
named-checkzone K21.com /etc/bind/db.K21.com

named

dig @localhost K21.com

nano /etc/bind/named.conf.local

zone "K21.com" {
    type slave;
    file "db.K21.com";
    masters { 10.74.3.2; }; // IP Tirion
};
named-checkconf 
Service named restart

echo "nameserver 10.74.3.2" > /etc/resolv.conf
echo "nameserver 10.74.3.3" >> /etc/resolv.conf
echo "nameserver 192.168.122.1" >> /etc/resolv.conf

